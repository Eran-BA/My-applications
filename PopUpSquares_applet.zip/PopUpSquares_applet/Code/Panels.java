import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;


public class Panels extends JPanel implements MouseListener , ActionListener {
    Random rand = new Random();
    final int n = 10;
    int tempN = n;
    final int x = 1000;
    int xCord=-500,yCord=-500;
    private Timer timer;
    int goodClicks=0;
    int badClicks=0;
    final int size=40;

    JPanel button = new JPanel();
    JPanel screen = new JPanel(){
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            float rR = rand.nextFloat();
            float gG = rand.nextFloat();
            float bB = rand.nextFloat();
            Color randomColor = new Color(rR, gG, bB);
            g.setColor(randomColor);
            g.fillRect(xCord,yCord,size,size);
        }
    };
    JButton newGameBtn = new JButton("New game");



    public Panels(){
        setLayout(new BorderLayout());
        button.add(newGameBtn);
        newGameBtn.addActionListener(this);
        add(button,BorderLayout.SOUTH);
        screen.setBackground(Color.WHITE);
        add(screen,BorderLayout.CENTER);
        screen.addMouseListener(this);
        timer = new Timer(x, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (tempN != 0) {
                    xCord = (int)(Math.random()*300);
                    yCord = (int)(Math.random()*300);
                    screen.repaint();
                    tempN--;
                }
                else if(tempN==0) {
                    timer.stop();
                    JOptionPane.showMessageDialog(null,"Good clicks: "+goodClicks+"\nBad clicks: "+badClicks);
                }
            }
        });
    }

        public void mouseClicked(MouseEvent e){
            int xPress = e.getX();
            int yPress = e.getY();
            if (xPress<=xCord+size && xPress >=xCord
                    && yPress<=yCord+size && yPress >= yCord ){
                goodClicks++;
            }
            else badClicks++;
        }
        public void mousePressed(MouseEvent e){}
        public void mouseReleased(MouseEvent e){}
        public void mouseEntered(MouseEvent e) {}
        public void mouseExited(MouseEvent e){}


        public void actionPerformed(ActionEvent e){
            if(e.getSource()==newGameBtn){
                tempN=n;
                goodClicks=badClicks=0;
                xCord=-100;
                yCord=-100;
                screen.repaint();
                timer.start();
            }
        }

    public static void main(String[] args)
    {
        JFrame frame = new JFrame();
        Panels panel = new Panels();
        frame.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400,400);
        frame.setVisible(true);
    }
}
