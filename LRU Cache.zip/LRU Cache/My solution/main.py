class Wrapper(object):

    def __init__(self, val, key):
        self.next = None
        self.prev = None
        self.val = val
        self.key = key

    def set_next(self,node):
        self.next=node

    def set_prev(self,node):
        self.prev=node


class DoublyLinkedList(object):
    def __init__(self):
        self.head=None
        self.lruTail=None


    def insert_to_front(self,node):
        if not node:
            return
        if not self.head:
            self.head=node
            self.lruTail=node
            node.next=None
            node.prev=None
            return node
        self.head.next=node
        node.prev=self.head
        self.head=self.head.next
        node.next=None
        return node


    def remove(self,node):
         if not node:
                return
         if node.prev and node.next:
             node.prev.next=node.next
             node.next.prev=node.prev
         elif node.prev: #removing the front
             self.head=self.head.prev
             self.head.next=None
         elif node.next:  #removing from tail
             self.lruTail=self.lruTail.next
             self.lruTail.prev=None
         else:#  removing from 1 node linked list or empty one
             self.lruTail=None
             self.head=None



    def returnLRU(self):
        return self.lruTail

class LRUCache(object):

    def __init__(self, capacity):
        self.capacity = capacity
        self.myMap = {}
        self.DLinkedList =  DoublyLinkedList()


    def get(self, key):
        if key not in self.myMap.keys():
            return -1
        node = self.myMap[key]
        val=node.val
        self.DLinkedList.remove(node)
        self.DLinkedList.insert_to_front(node)
        return val


    def put(self, key, value):
        if key in self.myMap.keys():
            nodeToRemove = self.myMap[key]
            self.DLinkedList.remove(nodeToRemove)
            self.myMap[key] =  self.DLinkedList.insert_to_front(Wrapper(value,key))
            return
        elif len(self.myMap)==self.capacity:
            shouldRemove = self.DLinkedList.returnLRU()
            del self.myMap[shouldRemove.key]
            self.DLinkedList.remove(shouldRemove)
            self.myMap[key]= self.DLinkedList.insert_to_front(Wrapper(value,key))
        else:
            self.myMap[key] =  self.DLinkedList.insert_to_front(Wrapper(value, key))
