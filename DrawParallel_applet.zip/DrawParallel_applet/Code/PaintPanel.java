import sun.applet.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.HashMap;
import java.util.Set;

public class PaintPanel extends JPanel implements MouseListener {

    Point src,dest;
    MainPanel m;
    PaintPanel p;
    public HashMap<Point,Point> line;

    boolean dragged=false;
    public PaintPanel(HashMap<Point,Point> l){
        line = l;
        src = new Point(-500,-500);
        dest = new Point(-550,-550);
        addMouseListener(this);
        setBackground(Color.white);

    }
    public void mousePressed(MouseEvent e){
        src = e.getPoint();
    }
    public void mouseReleased(MouseEvent e){
        dest = e.getPoint();
        line.put(src,dest);
        repaint();
        p.repaint();
    }

    public void mouseExited(MouseEvent e){}
    public void mouseClicked(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        draw(g);
    }
    public void draw(Graphics g){
        Set<Point> srcs = line.keySet();
        for(Point p : srcs){
            g.drawLine(p.x,p.y,line.get(p).x,line.get(p).y);
        }
    }

    public void setPanel (PaintPanel p){
        this.p=p;
    }
}
