import sun.applet.Main;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Set;

public class MainPanel extends JPanel {

    public PaintPanel p1,p2;
    public HashMap<Point,Point> line = new HashMap<>();
    public MainPanel(){
        p1 = new PaintPanel(line);
        p2 = new PaintPanel(line);
        p1.setPanel(p2);
        p2.setPanel(p1);
        setBackground(Color.BLACK);
        setLayout(new GridLayout(2,1,5,5));
        add(p1);
        add(p2);
    }

}
