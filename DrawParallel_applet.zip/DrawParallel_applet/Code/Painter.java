import javax.swing.*;
import java.awt.*;

public class Painter {
    public static void main(String[] args){
        JFrame application = new JFrame("Draw lines");
        MainPanel m= new MainPanel();
        application.add(m);
        application.add(new JLabel("Drag the mouse to draw"), BorderLayout.SOUTH);
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        application.setSize(500,500);
        application.setVisible(true);
    }
}
