import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Map;

public class PhoneBookPanel extends JPanel {
    private PhoneBook phoneBook;
    private JTable table;
    private JButton cmdAdd, cmdDelete, cmdUpdate, cmdSearch, cmdSave, cmdOpen;
    JFileChooser fc = new JFileChooser();

    public PhoneBookPanel() {
        //change Buttons font
        UIManager.put("Button.font", new FontUIResource(new Font("Dialog", Font.PLAIN, 14)));

        //create new PhoneBook object
        phoneBook = new PhoneBook();
        cmdAdd = new JButton("Add");
        cmdDelete = new JButton("Delete");
        cmdUpdate = new JButton("Update");
        cmdSearch = new JButton("Search");
        cmdSave = new JButton("Save");
        cmdOpen = new JButton("Open");
        table = new JTable(toTableModel(phoneBook.directory));
        table.setFont(new Font("Georgia", Font.PLAIN, 14));
        JScrollPane sp = new JScrollPane(table);
        this.setLayout(new BorderLayout());
        this.add(sp, BorderLayout.CENTER);
        //bottom panel containing buttons
        JPanel bottomButtons = new JPanel(new FlowLayout());
        bottomButtons.add(cmdAdd);
        bottomButtons.add(cmdDelete);
        bottomButtons.add(cmdUpdate);
        bottomButtons.add(cmdSearch);
        this.add(bottomButtons, BorderLayout.SOUTH);
        //top panel containing buttons
        JPanel topButtons = new JPanel(new FlowLayout());
        topButtons.add(cmdOpen);
        topButtons.add(cmdSave);
        this.add(topButtons, BorderLayout.NORTH);
        ControlsListener listener = new ControlsListener();
        cmdAdd.addActionListener(listener);
        cmdDelete.addActionListener(listener);
        cmdUpdate.addActionListener(listener);
        cmdSearch.addActionListener(listener);
        cmdSave.addActionListener(listener);
        cmdOpen.addActionListener(listener);
    }

    //method returning model for JTable
    public static <E> TableModel toTableModel(Map<E, E> map) {
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Name", "Number"}, 0)
        {@Override
            public boolean isCellEditable(int row, int column) {
                return false; }};
        for (Map.Entry<E, E> entry : map.entrySet())
            model.addRow(new Object[]{entry.getKey(), entry.getValue()});
        return model;
    }

    //method to rebuild table model and update UI
    public void updateTable(){
        table.setModel(toTableModel(phoneBook.directory));
    }

    private class ControlsListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            //Add
            if (e.getSource() == cmdAdd) {
                String name = JOptionPane.showInputDialog("Enter Name:");
                if (phoneBook.directory.containsKey(name))
                    JOptionPane.showMessageDialog(null,"Name already exists,please use update");
                else {
                    String num = null;
                    if (name != null)
                        num = JOptionPane.showInputDialog("Enter Number:");
                    if (num != null) {
                        phoneBook.insert(name, num);
                        updateTable();
                    }
                }
            }
            //Delete
            if (e.getSource() == cmdDelete) {
                String name = null;
                //if a row is selected, remove it.
                if (table.getSelectedRow() != -1) {
                    name = (String) table.getModel().getValueAt(table.getSelectedRow(), 0);
                    phoneBook.remove(name);
                    updateTable();
                }
                //if no row is selected, ask user for name to remove
                else {
                    name = JOptionPane.showInputDialog("Enter name to delete:");
                    if (name!=null) {
                        if (!phoneBook.directory.containsKey(name))
                            JOptionPane.showMessageDialog(null,"Name not in found");
                        else {
                            phoneBook.remove(name);
                            updateTable();
                        }
                    }
                }
            }
            //Update
            if (e.getSource() == cmdUpdate) {
                String name = null;
                String newNum = null;
                //if a row is selected, update it
                if (table.getSelectedRow() != -1) {
                    name = (String) table.getModel().getValueAt(table.getSelectedRow(), 0);
                    newNum = JOptionPane.showInputDialog("Enter new phone number:");
                    if (newNum!=null) {
                        phoneBook.update(name, newNum);
                        updateTable();
                    }
                }
                //else ask user for name to update
                else {
                    name = JOptionPane.showInputDialog("Enter name to update");
                    if (name!=null) {
                        if (phoneBook.directory.containsKey(name)) {
                            newNum = JOptionPane.showInputDialog("Enter new phone number:");

                            if (newNum!=null) {
                                phoneBook.update(name, newNum);
                                updateTable();
                            }
                        }
                        else
                            JOptionPane.showMessageDialog(null, "Name not in found");
                    }
                }
            }
            //Search
            if (e.getSource() == cmdSearch) {
                String name = JOptionPane.showInputDialog("Enter a name to search:");
                if (name!=null) {
                    if (phoneBook.directory.containsKey(name))
                        JOptionPane.showMessageDialog(null, "Number:\n" + phoneBook.directory.get(name));
                    else
                        JOptionPane.showMessageDialog(null, "Name not in found");
                }
            }
            //Save
            if (e.getSource() == cmdSave) {
                File f = null;
                fc.showSaveDialog(null);
                if (fc.getSelectedFile()!=null)
                    f = fc.getSelectedFile();
                try {
                    IOManager.writeObject(phoneBook, f);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error Saving File");
                }
            }
            //Open
            if (e.getSource() == cmdOpen) {
                File f=null;
                fc.showOpenDialog(null);
                if (fc.getSelectedFile()!=null)
                    f = fc.getSelectedFile();
                try {
                    phoneBook = IOManager.readObject(f);
                    updateTable();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null,"Error Opening File");
                }
            }
        }
    }
}
