import java.io.*;

public class IOManager {

    //Open PhoneBook object from a file
    public static PhoneBook readObject(File f) throws IOException {
        PhoneBook phoneBook;
        ObjectInputStream savedDirectory = new ObjectInputStream(new FileInputStream(f));
        try {
            phoneBook = (PhoneBook) savedDirectory.readObject();
            return phoneBook;
        } catch (ClassNotFoundException e) {
            e.getMessage();
        } catch (EOFException e) {
        }
        return null;
    }

    //save PhoneBook object to a file
    public static void writeObject(PhoneBook phoneBook,File f)throws IOException{
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(f));
        out.writeObject(phoneBook);
        out.close();
    }


}
