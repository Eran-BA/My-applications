import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args){
        JFrame f = new JFrame("Phonebook");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        PhoneBookPanel mainPanel= new PhoneBookPanel();
        f.add(mainPanel);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int height = screenSize.height *1/2 ;
        int width = screenSize.width * 1/2;
        f.setSize(width,height);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
}
