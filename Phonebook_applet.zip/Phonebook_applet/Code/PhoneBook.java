import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;

public class PhoneBook implements Serializable {
    TreeMap<String,String> directory;

    public PhoneBook(){
        directory = new TreeMap<>();
    }

    public void insert(String name,String number){
        directory.put(name,number);
    }

    public void remove(String name){
        directory.remove(name);
    }

    public void update(String name,String newNum){
        directory.put(name,newNum);
    }

    @Override
    public String toString(){
        String str="";
        for (Map.Entry entry : directory.entrySet())
            str += entry.getKey() + "\t\t\t\t" + entry.getValue() + "\n";
        return str;
    }
}
