import java.io.Serializable;
import java.util.*;

//A class represent a Phoneobook
public class Phonebook implements Serializable {
    private  TreeMap<String, String> map; //treeMap<K,V> : K- contact name, V-phone number

    public  Phonebook(){
        map= new TreeMap<String, String>();
    }

    public void addContact(String contactName, String phoneNum){
        map.put(contactName,phoneNum);
    }

    public void removeContact(String contactName){
        map.remove(contactName);
    }

    public String getNumber(String contactName){
        return (String)map.get(contactName);
    }

    public String toString(){
        String str="";
        Set<String> keys = map.keySet();
        for (String key: keys){
            str=str+key+"\t"+map.get(key)+"\n";
        }
        return str;
    }
}
