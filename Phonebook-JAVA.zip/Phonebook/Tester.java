import javax.swing.*;

public class Tester {
    public static void main(String args[]) {
        JFrame frame = new JFrame("Phonebook");//creating a frame which called 'Phonebook'
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        PhonebookPanel pbPanel = new PhonebookPanel();
        frame.add(pbPanel);
        frame.setVisible(true);
    }
}
