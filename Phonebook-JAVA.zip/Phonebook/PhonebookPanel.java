import sun.awt.windows.WDataTransferer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class PhonebookPanel extends JPanel {
    private final int SaveOption = 1;
    private final int OpenOption = 0;
    private Phonebook p;
    private JButton addContactPress,deleteContactPress,updateContactPress,searchContactPress,openPress,savePress;
    private JLabel lblName,lblPhoneNumber;
    private JTextField txtName,txtNumber;
    private  JTextArea bookData;
    private JScrollPane scroll;

    private Files fu;
    private File currentDir;

    public PhonebookPanel() {
        p = new Phonebook();
        addContactPress = new JButton("Add");
        deleteContactPress = new JButton("Delete");
        updateContactPress = new JButton("Update");
        searchContactPress = new JButton("Search");
        openPress = new JButton("Open");
        savePress = new JButton("Save");
        bookData = new JTextArea("");
        lblName=new JLabel("Name:");
        lblPhoneNumber=new JLabel("Number:");
        txtName=new JTextField(10);
        txtNumber=new JTextField(11);

        fu = new Files();
        currentDir = new File("C:\\");

        JPanel controls = new JPanel();
        controls.setLayout(new GridLayout(2, 5, 10, 10));
        controls.add(lblName);
        controls.add(txtName);
        controls.add(lblPhoneNumber);
        controls.add(txtNumber);
        controls.add(addContactPress);
        controls.add(deleteContactPress);
        controls.add(updateContactPress);
        controls.add(searchContactPress);

        ControlsListener cListener = new ControlsListener();
        addContactPress.addActionListener(cListener);
        deleteContactPress.addActionListener(cListener);
        updateContactPress.addActionListener(cListener);
        searchContactPress.addActionListener(cListener);
        openPress.addActionListener(cListener);
        savePress.addActionListener(cListener);

        JPanel upperControls = new JPanel();
        upperControls.add(savePress);
        upperControls.add(openPress);

        bookData.setFont(new Font("Serif", Font.ITALIC, 20));
        bookData.setEditable(false);
        JScrollPane scroll = new JScrollPane(bookData,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.setLayout(new BorderLayout());
        add(controls, BorderLayout.SOUTH);
        add(upperControls,BorderLayout.NORTH);
        add(scroll);
    }

    private void errorMsg(String msg)
    {
        JOptionPane.showMessageDialog(this,msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private File getFile(int what)
    {
        JFileChooser fc = new JFileChooser(currentDir);
        int returnVal=JFileChooser.CANCEL_OPTION;
        if(what==SaveOption)
            returnVal=fc.showSaveDialog(null);
        else if(what==OpenOption)
           returnVal=fc.showOpenDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            currentDir = fc.getSelectedFile();
            return fc.getSelectedFile();
        }
        return null;
    }

    private class ControlsListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource()==addContactPress)// || e.getSource()==updateContactPress)
            {
                if(!txtName.equals(null)&&!txtNumber.equals(null))
                {
                    if(txtNumber.getText().compareTo("")!=0 &&  txtName.getText().compareTo("")!=0)
                        p.addContact(txtName.getText(),txtNumber.getText());
                    else
                        JOptionPane.showMessageDialog(null,"You should enter both, name and number");

                }
            }
            else if(e.getSource()==updateContactPress){
                if(!txtName.equals(null)&&!txtNumber.equals(null)){
                    if(p.getNumber(txtName.getText())!=null)//checking if the contact is exist
                            p.addContact(txtName.getText(),txtNumber.getText());
                    else
                        JOptionPane.showMessageDialog(null,"No contact is found for updating");
                }

            }
            else if(e.getSource()==deleteContactPress)
            {
                if(!txtName.equals(null))
                {
                    p.removeContact(txtName.getText());
                }
            }
            else if(e.getSource()==searchContactPress){
                if(!txtName.equals(null))
                {
                    if(p.getNumber(txtName.getText())!=null)
                        JOptionPane.showMessageDialog(null,"The number of "+txtName.getText()+" is\n"+p.getNumber(txtName.getText()));
                    else
                        JOptionPane.showMessageDialog(null,"Couldn't find a contact");
                }
            }
            else if(e.getSource() == openPress){
                File f=getFile(OpenOption);
                String res ="";
                try {
                    if (f!=null)
                        p=fu.readObject(f);
                }
                catch (IOException ex){ errorMsg("Error in reading from File"); }
            }
            else if(e.getSource() == savePress){
                File f= getFile(SaveOption);
                try{
                    if(f!=null) {
                        fu.writeObject(f, p);
                        JOptionPane.showMessageDialog(PhonebookPanel.this, "Writing is done");
                    }
                }
                catch (IOException ex){ errorMsg("Error in Writing to File"); };
            }
            bookData.setText(p.toString());
        }
    }

}
