import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestTimer
{
    public void initUI() {
        JFrame frame = new JFrame("Shrink");//creating a frame which called 'Phonebook'
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.setSize(500,500);
        final MainPanel p = new MainPanel();
        frame.add(p);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent evt) {
                onExit(p);
            }
        });
    }

    public void onExit(MainPanel p) {
        p.c.Order=1;
        p.c.wakeAll();//waking the m threads so they can finish execute and die;
        p.c.waitUntilAllDead();//Main thread will wait until all the threads has died
        System.exit(0);
    }
}
