import javax.swing.*;

public class TestTimer
{
    public void initUI() {
        JFrame frame = new JFrame("Shrink");//creating a frame which called 'Phonebook'
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        MainPanel p = new MainPanel();
        frame.add(p);
        frame.setVisible(true);
    }
}
