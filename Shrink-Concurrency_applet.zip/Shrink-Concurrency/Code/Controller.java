//a monitor class, which control all the m threads.
public class Controller {
    public boolean mat[][];
    public boolean nextGmat[][];//this mat will be the mat of the next generation. I.E - After the transition on the initial mat
    public int maxThreads,activeThreads,waitings,Order,GOsign; //when order is execute, than GOsign and Order will initialized with '1'; otherwise '0'
    public int ispaint=0;

    public Controller(boolean matrix[][],int m){
        mat=matrix;
        maxThreads=m;
        nextGmat = new boolean[mat.length][mat.length];
        activeThreads=0;
        waitings=0;
        Order=0;
        GOsign=0;
    }

    public synchronized void waitForAll()
    {
        while(waitings!=maxThreads) {
            try {
                wait();
            } catch (InterruptedException e) {}
        }
    }

    public synchronized void waitForOrderToBeIssued()
    {
        while(Order!=0){
            try {
                wait();
            } catch (InterruptedException e) {}
        }
    }


    public synchronized int waitForOrder()//return 1 if the user press GO ,otherwise 0;
    {
        waitings++;
        notifyAll();
        while(Order==0){
            try {
                wait();
            }
            catch(InterruptedException e){}
        }
        waitings--;
        if(GOsign==1)
            return 1;
        else
            return 0;
    }

    public synchronized void waitForAll2(){
        if(waitings!=0){
            try {
                wait();
            }
            catch(InterruptedException e){}
        }
        else notifyAll();


    }

    public synchronized void wakeAll(){
        notifyAll();
    }


    public void started()
    {
        activeThreads++;
    }


    public synchronized void finished()
    {
        activeThreads--;
        notifyAll();
    }

    public synchronized void waitUntilAllDead(){
        while(activeThreads!=0){
            try {
                wait();
            }
            catch(InterruptedException e){}
        }
    }

    public synchronized void delay(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) { }
    }

}
