import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

//a panel which displaying the squares by the boolean matrix values
public class GamePanel extends JPanel {
    String sArr[];
    Controller c;//the monitor of the m threads
    int m,n,t;//m - number of threads, n - size of the matrix, t- number of transitions
    int x,y;//(x,y) point of the panel

    public GamePanel(){
        sArr=new CustomizedJOptionPane().displayGUIAndGetText();//extracting m and n from the dialog box;
        m=Integer.parseInt(sArr[0]);
        n=Integer.parseInt(sArr[1]);
        t=Integer.parseInt(sArr[2]);

        c=new Controller(new boolean[n][n],m);
        addMouseListener(new Listener());
    }

    private class Listener extends MouseAdapter
    {
        //changing the color of the square when a click has made;
        public void mouseClicked(MouseEvent e) {
            x = e.getX();
            y = e.getY();
            int widthOfOneSquare = getWidth() / n;
            int heightOfOneSquare = getHeight() / n;
            //Identification of indexes i and j from the (x,y) point
            int j = x/widthOfOneSquare;
            int i = y/heightOfOneSquare;
            if(i<0 || i>n-1 || j<0 || j>n-1)
                return;
            c.mat[i][j]=!c.mat[i][j];
            repaint();
        }
    }

    //painting the squares by the matrix values;
    public void paintComponent(Graphics g) {
        c.ispaint=0;
        int width = getWidth();
        int height = getHeight();
        int widthOfOneSquare = (width ) / n; //calculating the width and height of one square
        int heightOfOneSquare = (height) / n;
        super.paintComponent(g);
        int x1 = 0;
        int y1 = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (c.mat[i][j] == true)
                    g.setColor(Color.black);
                else
                    g.setColor(Color.white);
                g.fillRect(x1, y1, widthOfOneSquare, heightOfOneSquare);
                g.setColor(Color.lightGray);
                g.drawRect(x1,y1,widthOfOneSquare,heightOfOneSquare);
                x1 = x1 + widthOfOneSquare;
            }
            y1 = y1 + heightOfOneSquare;
            x1 = 0;

        }
    }

}

