import sun.applet.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainPanel extends JPanel {
    GamePanel gameP; // A panel which display the squares
    JButton stepPress,resetPress,goPress;
    JPanel controlsPanel,framePanel;
    PixelChangerThread arr[];//Array of m threads;
    int n ;//n is the size of the matrix that the user has set
    int m ;//m is the number of threads that the user has set
    int t ;//t is the number of transitions that should execute
    Controller c;// c is the monitor that control all the threads;
    private int count = 0;
    private Timer timer;

    public MainPanel(){
        gameP = new GamePanel();
        controlsPanel = new JPanel();
        framePanel = new JPanel();
        stepPress=new JButton("1 step");
        resetPress=new JButton("reset");
        goPress = new JButton("GO!");
        controlsPanel.setLayout(new GridLayout(2, 2, 10, 10));
        controlsPanel.add(stepPress);
        controlsPanel.add(goPress);
        controlsPanel.add(resetPress);

        framePanel.add(controlsPanel);
        this.setLayout(new BorderLayout());
        add(framePanel, BorderLayout.SOUTH);
        add(gameP,BorderLayout.CENTER);


        ControlsListener cListener = new ControlsListener();
        stepPress.addActionListener(cListener);
        resetPress.addActionListener(cListener);
        goPress.addActionListener(cListener);

        t=gameP.t;
        //-----------Set the threads---------
        n=gameP.n;//n is the size of the matrix that the user has set
        m=gameP.m;//m is the number of threads that the user has set
        c = gameP.c;// c is the monitor that control all the threads;
        arr=new PixelChangerThread[m];
        PixelChangerThread.setPixelChangerThreads(arr,c,n,m);//set how the m threads will work, I.E on which lines of the matrix each thread is responsible

        //-------Define the timer--------
        timer = new Timer(1000, new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (count != 0) {
                        count--;
                        c.GOsign=1;//change the GOsign from 0 to 1;
                        c.Order=1;//change the Order from 0 to 1;
                        c.wakeAll();//wake all the m threads;
                        c.waitForOrderToBeIssued();
                        c.waitForAll();//stoping the MainPanel thread until all the others m threads will wait for the next order
                        c.mat=c.nextGmat;
                        c.nextGmat=new boolean[n][n];
                        gameP.repaint();
                    } else
                        timer.stop();

                }
            });
    }


    private class ControlsListener implements ActionListener{
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource()==stepPress)
            {
                count=1;
                timer.start();//making 1 step/transition on the matrix of squars
            }
            else if(e.getSource()==goPress){
                    count=t;
                    timer.start();
            }
            else if(e.getSource()==resetPress)
            {
                c.mat=new boolean[n][n];
                c.nextGmat=new boolean[n][n];
                gameP.repaint();
            }
        }
    }

}
