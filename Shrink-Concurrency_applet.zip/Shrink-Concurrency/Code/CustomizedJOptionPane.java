import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
//a class which built for making a customized dialog box
public class CustomizedJOptionPane {

    private JLabel labelM, labelN,labelT;
    private JTextField tfieldM, tfieldN, tfieldT;
    private JLabel statusLabel;

    private static final int GAP = 5;

    public String[] displayGUIAndGetText() {
        String sArr[]= new String[3];
        JOptionPane.showMessageDialog(null, getPanel());
        sArr[0]=tfieldM.getText();
        sArr[1]=tfieldN.getText();
        sArr[2]=tfieldT.getText();
        return sArr;
    }

    private JPanel getPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2));
        labelM = new JLabel("Enter m : ", JLabel.CENTER);
        tfieldM = new JTextField(2);
        labelN = new JLabel(" n : ", JLabel.CENTER);
        tfieldN = new JTextField(2);
        labelT = new JLabel(" t : " ,JLabel.CENTER);
        tfieldT = new JTextField(2);
        JPanel controlPanel = new JPanel();
        controlPanel.add(labelM);
        controlPanel.add(tfieldM);
        controlPanel.add(labelN);
        controlPanel.add(tfieldN);
        controlPanel.add(labelT);
        controlPanel.add(tfieldT);

        panel.add(controlPanel);
        statusLabel = new JLabel("", JLabel.CENTER);
        panel.add(statusLabel);

        return panel;

    }
}
