//A class of the m threads, each one of them is a "Pixel Changer"
public class PixelChangerThread extends Thread {
    private Controller cont;//cont is a monitor of the m threads;
    private int startLine,finishLine;//the start line  and the finish line in the matrix of a one thread.

    public PixelChangerThread(Controller c,int sLine,int fLine){
        cont=c;
        startLine=sLine;
        finishLine=fLine;
    }
    public void run(){
        int status=1;
        while(status==1){
            status=cont.waitForOrder();
            cont.waitForAll2();//waiting for all the threads to recieve an order;
            cont.Order=0;
            cont.GOsign=0;
            if(status==1){//1 for GO sign
                for(int i=startLine;i<=finishLine && i<cont.mat.length ;i++){
                    for(int j=0;j<cont.mat.length;j++){
                        if(shouldFliped(cont.mat,i,j))
                            cont.nextGmat[i][j]=!cont.mat[i][j];
                        else
                            cont.nextGmat[i][j]=cont.mat[i][j];
                    }
                }
            }
            else {
                cont.finished();
            }


        }

    }

    //The function returning 'true' when the pixle at index i,j should be fliped ,otherwise 'false'
    private static boolean shouldFliped(boolean [][]m,int i,int j){
        if(m[i][j]==false)
            return false;
        return !f(m,i,j,2);//'f' checking if the cell of the black pixle at index i,j should not be flipped, if 'f' return 'true' than it shouldn't be fliped, otherwise it should.
    }

    private static boolean f(boolean [][]m, int i,int j,int deep){
        if(deep==0)
            return true;
        if(i<0 || i>m.length-1 || j<0 || j>m.length-1)
            return true;
        return m[i][j]&&
                f(m,i-1,j-1,deep-1)&&f(m,i+1,j+1,deep-1)&&
                f(m,i+1,j-1,deep-1)&&f(m,i-1,j+1,deep-1)&&
                f(m,i,j-1,deep-1)&&f(m,i,j+1,deep-1)&&
                f(m,i-1,j,deep-1)&&f(m,i+1,j,deep-1);
    }


    //A function which set how the m threads will work, I.E on which lines of the matrix each thread is responsible
    public static void setPixelChangerThreads(PixelChangerThread arr[],Controller c,int n,int m){

        int x=n/m;
        int i=0;
        int k=0;
        int tmp;
        if(x==0)
            x++;
        for(k=0;k<m-1 && k<n ;k++) {
            arr[k] = new PixelChangerThread(c, i, i + x - 1);
            i += x;
        }
        if(k==m-1 && k<n){
            arr[k]=new PixelChangerThread(c,i,n-1);
            c.maxThreads=k+1;
            tmp=k+1;//tmp==m
        }
        else{
            c.maxThreads=k;
            tmp=k;//tmp==n
        }

        k=0;

        while(k<tmp){
            c.started();
            arr[k].start();
            k++;
        }
        c.waitForAll();//stoping the MainPanel thread until all the threads will wait for order
    }
}


